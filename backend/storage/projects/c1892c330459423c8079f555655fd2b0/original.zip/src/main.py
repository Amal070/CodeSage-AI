print('Hello CodeSage')
