def normal(): pass
